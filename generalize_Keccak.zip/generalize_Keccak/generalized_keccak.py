import os
import sys

def rotate(x, shift, lane_size):
    """Rotate value x left by shift bits, bounded by lane_size."""
    if lane_size == 0:
        return 0
    shift %= lane_size
    return ((x << shift) | (x >> (lane_size - shift))) & ((1 << lane_size) - 1)

def theta(state, lane_size):
    C = [0] * 5
    D = [0] * 5
    for x in range(5):
        C[x] = state[0][x] ^ state[1][x] ^ state[2][x] ^ state[3][x] ^ state[4][x]
    for x in range(5):
        D[x] = C[(x - 1) % 5] ^ rotate(C[(x + 1) % 5], 1, lane_size)
    for y in range(5):
        for x in range(5):
            state[y][x] ^= D[x]
    return state

def rho(state, lane_size):
    rho_offsets = [
        [0, 1, 62, 28, 27],
        [36, 44, 6, 55, 20],
        [3, 10, 43, 25, 39],
        [41, 45, 15, 21, 8],
        [18, 2, 61, 56, 14]
    ]
    for y in range(5):
        for x in range(5):
            offset = rho_offsets[y][x] % lane_size
            value = state[y][x]
            state[y][x] = ((value << offset) | (value >> (lane_size - offset))) & ((1 << lane_size) - 1)
    return state

def pi(state):
    new_state = [[0] * 5 for _ in range(5)]
    for y in range(5):
        for x in range(5):
            # Standard Pi: A'[x, y] = A[(x + 3y) % 5, x]
            # Mapping this to our state[y][x] representation:
            # new_state[y][x] = state[x][(x + 3*y) % 5]
            new_state[y][x] = state[x][(x + 3 * y) % 5]
    return new_state

def chi(state, lane_size):
    new_state = [[0]*5 for _ in range(5)]
    mask = (1 << lane_size) - 1
    for y in range(5):
        for x in range(5):
            new_state[y][x] = state[y][x] ^ ((~state[y][(x+1)%5] & mask) & state[y][(x+2)%5])
    return new_state

def iota(state, round_idx, RC):
    if round_idx < len(RC):
        rc = RC[round_idx]
        state[0][0] ^= rc
    return state

def display_state(state, lane_size):
    fmt = f'0{(lane_size + 3) // 4}x'  # hex padding
    for row in state:
        print(' '.join(f'{x:{fmt}}' for x in row))
    print()

def keccak_permutation(state, lane_size, rounds, RC):
    current_state = [row[:] for row in state]
    for r in range(rounds):
        print(f"--- Round {r+1} ---")
        current_state = theta(current_state, lane_size)
        current_state = rho(current_state, lane_size)
        current_state = pi(current_state)
        current_state = chi(current_state, lane_size)
        current_state = iota(current_state, r, RC)
        display_state(current_state, lane_size)
    return current_state

def parse_input_file(file_path):
    with open(file_path, 'r') as f:
        lines = f.readlines()
    
    config = {}
    state = []
    reading_state = False
    
    for line in lines:
        line = line.strip()
        if not line or line.startswith('#'):
            continue
        
        if line.lower().startswith('lane_size:'):
            config['lane_size'] = int(line.split(':')[1].strip())
        elif line.lower().startswith('rounds:'):
            config['rounds'] = int(line.split(':')[1].strip())
        elif line.lower().startswith('round_constants:'):
            rc_str = line.split(':')[1].strip()
            config['RC'] = [int(x.strip(), 16) for x in rc_str.split(',') if x.strip()]
        elif line.lower().startswith('initial_state:'):
            reading_state = True
        elif reading_state:
            row = [int(x.strip(), 16) for x in line.split() if x.strip()]
            if row:
                state.append(row)
    
    if len(state) != 5 or any(len(row) != 5 for row in state):
        print("Warning: State format might be incorrect (expected 5x5). Using all zeros if missing.")
        if not state:
            state = [[0]*5 for _ in range(5)]
        else:
            # Pad or trim to 5x5
            while len(state) < 5:
                state.append([0]*5)
            for i in range(5):
                while len(state[i]) < 5:
                    state[i].append(0)
                state[i] = state[i][:5]
            state = state[:5]

    config['initial_state'] = state
    return config

def main():
    if len(sys.argv) < 2:
        print("Usage: python3 generalized_keccak.py <input_config_file>")
        sys.exit(1)
    
    input_file = sys.argv[1]
    if not os.path.exists(input_file):
        print(f"Error: File {input_file} not found.")
        sys.exit(1)
    
    config = parse_input_file(input_file)
    
    lane_size = config.get('lane_size', 16)
    rounds = config.get('rounds', 0)
    RC = config.get('RC', [])
    initial_state = config.get('initial_state', [[0]*5 for _ in range(5)])
    
    print(f"Configurations:")
    print(f"  Lane Size: {lane_size}")
    print(f"  Rounds: {rounds}")
    print(f"  Round Constants: {[hex(rc) for rc in RC]}")
    print("Initial State:")
    display_state(initial_state, lane_size)
    
    final_state = keccak_permutation(initial_state, lane_size, rounds, RC)
    
    print("Final Output State:")
    display_state(final_state, lane_size)

if __name__ == "__main__":
    main()
